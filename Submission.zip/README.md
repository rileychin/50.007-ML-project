
# ML Project 50.007


1) Open notebook in google colab / environment of your choice
2) Create 2 folders for ./ES and ./RU
3) Place dev.in and dev.out for both datasets into the respective folders
4) Place the file evalResult.py in ./ directory
5) Run all cells in the notebook

